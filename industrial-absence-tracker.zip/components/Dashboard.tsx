
import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { Translations, AbsenceRecord, ShiftKey, DepartmentKey } from '../types';
import { Sparkles, Loader2, Info } from 'lucide-react';

interface DashboardProps {
  t: Translations;
  records: AbsenceRecord[];
  isRTL: boolean;
  onAiAnalyze: () => void;
  aiInsight: string | null;
  isAiLoading: boolean;
}

const COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

const Dashboard: React.FC<DashboardProps> = ({ t, records, isRTL, onAiAnalyze, aiInsight, isAiLoading }) => {
  
  const shiftStats = useMemo(() => {
    const data: Record<ShiftKey, { total: number, count: number }> = {
      morning: { total: 0, count: 0 },
      afternoon: { total: 0, count: 0 },
      night: { total: 0, count: 0 }
    };
    records.forEach(r => {
      data[r.shift].total += r.rate;
      data[r.shift].count += 1;
    });
    return (Object.keys(data) as ShiftKey[]).map(key => ({
      name: t.shifts[key],
      rate: data[key].count > 0 ? parseFloat((data[key].total / data[key].count).toFixed(2)) : 0
    }));
  }, [records, t.shifts]);

  const deptStats = useMemo(() => {
    const data: Record<DepartmentKey, number> = {
      production: 0,
      logistics: 0,
      maintenance: 0,
      quality: 0
    };
    records.forEach(r => {
      data[r.department] += r.absences;
    });
    return (Object.keys(data) as DepartmentKey[]).map(key => ({
      name: t.departments[key],
      value: data[key]
    })).filter(d => d.value > 0);
  }, [records, t.departments]);

  if (records.length === 0) {
    return (
      <div className="bg-white rounded-2xl p-12 text-center border border-dashed border-gray-300">
        <Info className="w-12 h-12 text-gray-300 mx-auto mb-4" />
        <p className="text-gray-500 font-medium">{t.noData}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold mb-4 text-gray-700">{t.avgShiftRate} (%)</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={shiftStats} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} reversed={isRTL} />
                <YAxis orientation={isRTL ? 'right' : 'left'} tick={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="rate" fill="#6366f1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold mb-4 text-gray-700">{t.deptDistribution}</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={deptStats}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {deptStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend layout="horizontal" verticalAlign="bottom" align="center" />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* AI Analysis Section */}
      <div className="bg-indigo-900 text-white rounded-2xl p-6 shadow-xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
          <Sparkles className="w-24 h-24" />
        </div>
        
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold flex items-center gap-2">
              <Sparkles className="w-5 h-5" />
              {t.aiAnalysis}
            </h3>
            <button 
              onClick={onAiAnalyze}
              disabled={isAiLoading}
              className="bg-white text-indigo-900 px-4 py-2 rounded-lg font-bold text-sm hover:bg-indigo-50 transition-colors disabled:opacity-50 flex items-center gap-2"
            >
              {isAiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
              {t.summary}
            </button>
          </div>

          {aiInsight ? (
            <div className="bg-indigo-800/50 p-4 rounded-xl border border-indigo-400/30 text-indigo-50 leading-relaxed italic">
              "{aiInsight}"
            </div>
          ) : (
            <p className="text-indigo-200 text-sm">
              Solicite un resumen ejecutivo basado en las tendencias actuales de ausentismo.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
