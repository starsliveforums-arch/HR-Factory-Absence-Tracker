
import React from 'react';
import { Translations, AbsenceRecord } from '../types';
import { Download, Trash2, Trash, Calendar } from 'lucide-react';

interface HistoryProps {
  t: Translations;
  records: AbsenceRecord[];
  onDelete: (id: string) => void;
  onClearAll: () => void;
  onExport: () => void;
  isRTL: boolean;
}

const History: React.FC<HistoryProps> = ({ t, records, onDelete, onClearAll, onExport, isRTL }) => {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden animate-fadeIn">
      <div className="p-6 border-b border-gray-100 flex flex-wrap items-center justify-between gap-4">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
          <Calendar className="w-6 h-6 text-indigo-600" />
          {t.history}
        </h2>
        
        <div className="flex gap-2">
          <button 
            onClick={onExport}
            className="bg-indigo-50 text-indigo-700 px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 hover:bg-indigo-100 transition-colors"
          >
            <Download className="w-4 h-4" />
            {t.export}
          </button>
          <button 
            onClick={onClearAll}
            className="bg-red-50 text-red-600 px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 hover:bg-red-100 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            {t.clear}
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left" dir={isRTL ? 'rtl' : 'ltr'}>
          <thead className="bg-gray-50 text-gray-500 uppercase text-xs font-bold tracking-wider">
            <tr>
              <th className="px-6 py-4">{t.date}</th>
              <th className="px-6 py-4">{t.department}</th>
              <th className="px-6 py-4">{t.shift}</th>
              <th className="px-6 py-4 text-center">{t.absenceRate}</th>
              <th className="px-6 py-4"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {records.map((record) => (
              <tr key={record.id} className="hover:bg-gray-50 transition-colors group">
                <td className="px-6 py-4 text-sm whitespace-nowrap">{record.date}</td>
                <td className="px-6 py-4 text-sm font-medium">{t.departments[record.department]}</td>
                <td className="px-6 py-4 text-sm text-gray-600">{t.shifts[record.shift]}</td>
                <td className="px-6 py-4 text-center">
                  <span className={`px-2 py-1 rounded text-xs font-bold ${
                    record.rate < 5 ? 'bg-green-100 text-green-700' :
                    record.rate > 10 ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                  }`}>
                    {record.rate.toFixed(1)}%
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button 
                    onClick={() => onDelete(record.id)}
                    className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-full transition-all opacity-0 group-hover:opacity-100"
                  >
                    <Trash className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
            {records.length === 0 && (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-gray-400 italic">
                  {t.noData}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default History;
