
import React, { useState } from 'react';
import { Translations, DepartmentKey, ShiftKey, AbsenceRecord } from '../types';
import { Save, AlertCircle } from 'lucide-react';

interface EntryFormProps {
  t: Translations;
  onAdd: (record: Omit<AbsenceRecord, 'id' | 'createdAt'>) => void;
  isRTL: boolean;
}

const EntryForm: React.FC<EntryFormProps> = ({ t, onAdd, isRTL }) => {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [department, setDepartment] = useState<DepartmentKey>('production');
  const [shift, setShift] = useState<ShiftKey>('morning');
  const [totalStaff, setTotalStaff] = useState<string>('100');
  const [absences, setAbsences] = useState<string>('0');

  const staffCount = parseInt(totalStaff) || 0;
  const absenceCount = parseInt(absences) || 0;
  const rate = staffCount > 0 ? (absenceCount / staffCount) * 100 : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (staffCount <= 0) return;
    onAdd({
      date,
      department,
      shift,
      totalStaff: staffCount,
      absences: absenceCount,
      rate
    });
    setAbsences('0');
  };

  const getRateColor = (r: number) => {
    if (r < 5) return 'text-green-600';
    if (r > 10) return 'text-red-600';
    return 'text-amber-600';
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 animate-fadeIn">
      <h2 className="text-2xl font-bold mb-6 text-gray-800 flex items-center gap-2">
        <Save className="w-6 h-6 text-indigo-600" />
        {t.newEntry}
      </h2>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">{t.date}</label>
            <input 
              type="date" 
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">{t.department}</label>
            <select 
              value={department}
              onChange={(e) => setDepartment(e.target.value as DepartmentKey)}
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none appearance-none"
            >
              {(Object.keys(t.departments) as Array<DepartmentKey>).map(key => (
                <option key={key} value={key}>{t.departments[key]}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">{t.shift}</label>
            <select 
              value={shift}
              onChange={(e) => setShift(e.target.value as ShiftKey)}
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none appearance-none"
            >
              {(Object.keys(t.shifts) as Array<ShiftKey>).map(key => (
                <option key={key} value={key}>{t.shifts[key]}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">{t.totalStaff}</label>
            <input 
              type="number" 
              min="1"
              value={totalStaff}
              onChange={(e) => setTotalStaff(e.target.value)}
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">{t.absences}</label>
            <input 
              type="number" 
              min="0"
              max={totalStaff}
              value={absences}
              onChange={(e) => setAbsences(e.target.value)}
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
            />
          </div>
        </div>

        <div className="bg-indigo-50 rounded-xl p-5 border border-indigo-100 flex flex-col items-center justify-center">
          <span className="text-sm text-indigo-700 uppercase tracking-wider font-bold mb-1">{t.absenceRate}</span>
          <div className={`text-5xl font-black ${getRateColor(rate)}`}>
            {rate.toFixed(1)}%
          </div>
        </div>

        <button 
          type="submit"
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center gap-2"
        >
          <Save className="w-5 h-5" />
          {t.save}
        </button>
      </form>
    </div>
  );
};

export default EntryForm;
